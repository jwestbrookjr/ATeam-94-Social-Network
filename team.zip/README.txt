READ

Course: CS400
Semester: Fall 2019
Project Name: Social Network
Team Members:
1. Sam Peaslee, LEC002, speaslee@wisc.edu
2. Jon Westbrook, LEC002, jwestbrook@wisc.edu
3. Grant Hellenbran, LEC002, ghellenbran2@wisc.edu
4. Alex Bush, LEC002, abush4@wisc.edu
5. Cole Christophel, LEC001, cchristophel@wisc.edu

Jon Westbrook and Alex Bush were on the same XTeam together (XTeam 100).
